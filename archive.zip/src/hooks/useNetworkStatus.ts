/**
 * useNetworkStatus.ts — Mobile-compatible network status hook
 *
 * Uses React Native's built-in NetInfo instead of the browser navigator.onLine
 */

import { useState, useEffect } from 'react';
import NetInfo from '@react-native-community/netinfo';

export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsOnline(state.isConnected ?? true);
    });
    return () => unsubscribe();
  }, []);

  return { isOnline };
}
